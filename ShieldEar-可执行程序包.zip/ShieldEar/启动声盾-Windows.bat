@echo off
chcp 65001 >nul
title 声盾 ShieldEar · AI 语音鉴伪平台
cd /d "%~dp0"

rem ── 选择 Node 运行时：优先系统 Node，缺失时使用包内便携版 ──
set "NODE_EXE="
where node >nul 2>nul && set "NODE_EXE=node"
if not defined NODE_EXE if exist "%~dp0node-win\node.exe" set "NODE_EXE=%~dp0node-win\node.exe"
if not defined NODE_EXE (
  echo [启动失败] 未找到 Node.js 运行时，请安装 Node.js 20 或更高版本后重试。
  echo 下载地址: https://nodejs.org/
  pause
  exit /b 1
)

rem ── espeak-ng 离线合成组件（存在则启用） ──
if exist "%~dp0espeak-ng\espeak-ng.exe" (
  set "PATH=%~dp0espeak-ng;%PATH%"
  set "ESPEAK_DATA_PATH=%~dp0espeak-ng"
)

cd /d "%~dp0server"
echo 声盾正在启动（首次约需数秒），浏览器将自动打开 http://127.0.0.1:3000
echo 演示期间请保持本窗口开启，使用完毕直接关闭本窗口即可停止服务。
start "" /min cmd /c "timeout /t 5 /nobreak >nul & start http://127.0.0.1:3000"
"%NODE_EXE%" run-shield.js
echo.
echo 服务已停止。
pause
