/**
 * 声盾 ShieldEar 启动引导 —— 加载 Next standalone 服务前设置运行时环境
 * 数据库自动定位到包内 server/db/custom.db，与启动时的当前目录解耦
 */
const path = require("path");
process.env.NODE_ENV = "production";
process.env.PORT = process.env.PORT || "3000";
process.env.HOSTNAME = process.env.HOSTNAME || "127.0.0.1";
if (!process.env.DATABASE_URL) {
  process.env.DATABASE_URL = "file:" + path.join(__dirname, "db", "custom.db");
}
require("./server.js");
