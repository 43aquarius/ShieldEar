var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tts-challenge/route.js")
R.c("server/chunks/[root-of-the-server]__8f58a8b0._.js")
R.c("server/chunks/src_lib_audio_wav_ts_07fdf1f0._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__f58cdffd._.js")
R.c("server/chunks/_next-internal_server_app_api_tts-challenge_route_actions_3477ab4a.js")
R.m(8382)
module.exports=R.m(8382).exports
