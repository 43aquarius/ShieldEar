var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/evidence/[caseNo]/route.js")
R.c("server/chunks/[root-of-the-server]__b32fef04._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_evidence_[caseNo]_route_actions_afb6db69.js")
R.m(38908)
module.exports=R.m(38908).exports
