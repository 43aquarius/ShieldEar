var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cases/route.js")
R.c("server/chunks/[root-of-the-server]__db2e42ba._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_cases_route_actions_76363a14.js")
R.m(51971)
module.exports=R.m(51971).exports
