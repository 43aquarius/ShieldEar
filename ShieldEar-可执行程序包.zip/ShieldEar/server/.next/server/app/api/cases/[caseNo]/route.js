var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cases/[caseNo]/route.js")
R.c("server/chunks/[root-of-the-server]__ca8808fa._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_cases_[caseNo]_route_actions_a628f42a.js")
R.m(8154)
module.exports=R.m(8154).exports
