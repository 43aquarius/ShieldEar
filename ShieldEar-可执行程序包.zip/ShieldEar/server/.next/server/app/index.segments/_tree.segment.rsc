:HL["/_next/static/chunks/a799cc89dbddc670.css","style"]
0:{"buildId":"mC1AVFxD6zmDWLwfxdXbx","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
