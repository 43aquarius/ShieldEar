1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/77d2792b7dba5e63.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/77d2792b7dba5e63.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/77d2792b7dba5e63.js"],"IconMark"]
0:{"buildId":"mC1AVFxD6zmDWLwfxdXbx","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#0a0f0d"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"声盾 ShieldEar — AI 语音诈骗实时鉴伪反诈平台"}],["$","meta","1",{"name":"description","content":"声盾：面向 AI 语音诈骗的实时鉴伪反诈平台。滑动窗口流式检测、逐窗置信度、可解释特征剖面、SHA-256 存证与核验报告，构建反诈验真业务闭环。"}],["$","meta","2",{"name":"keywords","content":"AI语音鉴伪,深度伪造检测,反诈,声盾,ShieldEar,音频取证,合成语音检测"}],["$","link","3",{"rel":"icon","href":"/favicon.svg"}],["$","$L5","4",{}]]}]}]}],null]}],"loading":null,"isPartial":false}
