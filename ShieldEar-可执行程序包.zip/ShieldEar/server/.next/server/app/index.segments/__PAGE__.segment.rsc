1:"$Sreact.fragment"
2:I[88156,["/_next/static/chunks/9f157f953cd48d7a.js","/_next/static/chunks/4a90f0cf0e090302.js","/_next/static/chunks/bd5c7252780c18ed.js"],"ShieldApp"]
3:I[97367,["/_next/static/chunks/77d2792b7dba5e63.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"mC1AVFxD6zmDWLwfxdXbx","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/bd5c7252780c18ed.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
