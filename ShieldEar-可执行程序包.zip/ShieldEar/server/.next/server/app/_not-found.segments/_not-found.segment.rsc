1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/9f157f953cd48d7a.js","/_next/static/chunks/4a90f0cf0e090302.js","/_next/static/chunks/77d2792b7dba5e63.js"],"default"]
3:I[37457,["/_next/static/chunks/9f157f953cd48d7a.js","/_next/static/chunks/4a90f0cf0e090302.js","/_next/static/chunks/77d2792b7dba5e63.js"],"default"]
0:{"buildId":"mC1AVFxD6zmDWLwfxdXbx","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
