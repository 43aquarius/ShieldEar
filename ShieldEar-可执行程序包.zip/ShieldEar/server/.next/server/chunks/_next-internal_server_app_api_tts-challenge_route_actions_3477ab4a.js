module.exports=[38902,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tts-challenge_route_actions_3477ab4a.js.map