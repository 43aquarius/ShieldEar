module.exports=[72368,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cases_%5BcaseNo%5D_route_actions_a628f42a.js.map