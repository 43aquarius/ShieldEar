#!/usr/bin/env bash
# 声盾 ShieldEar · Linux / macOS 启动脚本
cd "$(dirname "$0")"
NODE_EXE="$(command -v node 2>/dev/null || true)"
if [ -z "$NODE_EXE" ]; then
  echo "[启动失败] 未找到 Node.js，请安装 Node.js 20 或更高版本后重试（https://nodejs.org/）"
  exit 1
fi
cd server
echo "声盾正在启动（首次约需数秒），浏览器将自动打开 http://127.0.0.1:3000"
echo "演示期间请保持本终端运行，使用完毕按 Ctrl+C 停止服务。"
( sleep 5; xdg-open http://127.0.0.1:3000 >/dev/null 2>&1 || open http://127.0.0.1:3000 >/dev/null 2>&1 ) &
exec "$NODE_EXE" run-shield.js
